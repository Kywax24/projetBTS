﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class codeFenExo16
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.textNom = New System.Windows.Forms.TextBox()
        Me.textPrenom = New System.Windows.Forms.TextBox()
        Me.textDateDeNaissance = New System.Windows.Forms.TextBox()
        Me.labelNom = New System.Windows.Forms.Label()
        Me.labelPrenom = New System.Windows.Forms.Label()
        Me.labelDateNaissance = New System.Windows.Forms.Label()
        Me.buttonFermer = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'textNom
        '
        Me.textNom.Location = New System.Drawing.Point(198, 27)
        Me.textNom.Name = "textNom"
        Me.textNom.Size = New System.Drawing.Size(100, 20)
        Me.textNom.TabIndex = 0
        '
        'textPrenom
        '
        Me.textPrenom.Location = New System.Drawing.Point(198, 79)
        Me.textPrenom.Name = "textPrenom"
        Me.textPrenom.Size = New System.Drawing.Size(100, 20)
        Me.textPrenom.TabIndex = 1
        '
        'textDateDeNaissance
        '
        Me.textDateDeNaissance.Location = New System.Drawing.Point(198, 130)
        Me.textDateDeNaissance.Name = "textDateDeNaissance"
        Me.textDateDeNaissance.Size = New System.Drawing.Size(100, 20)
        Me.textDateDeNaissance.TabIndex = 2
        '
        'labelNom
        '
        Me.labelNom.AutoSize = True
        Me.labelNom.Location = New System.Drawing.Point(149, 30)
        Me.labelNom.Name = "labelNom"
        Me.labelNom.Size = New System.Drawing.Size(35, 13)
        Me.labelNom.TabIndex = 3
        Me.labelNom.Text = "Nom :"
        '
        'labelPrenom
        '
        Me.labelPrenom.AutoSize = True
        Me.labelPrenom.Location = New System.Drawing.Point(135, 82)
        Me.labelPrenom.Name = "labelPrenom"
        Me.labelPrenom.Size = New System.Drawing.Size(49, 13)
        Me.labelPrenom.TabIndex = 4
        Me.labelPrenom.Text = "Prénom :"
        '
        'labelDateNaissance
        '
        Me.labelDateNaissance.AutoSize = True
        Me.labelDateNaissance.Location = New System.Drawing.Point(34, 133)
        Me.labelDateNaissance.Name = "labelDateNaissance"
        Me.labelDateNaissance.Size = New System.Drawing.Size(150, 13)
        Me.labelDateNaissance.TabIndex = 5
        Me.labelDateNaissance.Text = "Date de naissance (**/**/****):"
        '
        'buttonFermer
        '
        Me.buttonFermer.Location = New System.Drawing.Point(198, 186)
        Me.buttonFermer.Name = "buttonFermer"
        Me.buttonFermer.Size = New System.Drawing.Size(100, 23)
        Me.buttonFermer.TabIndex = 6
        Me.buttonFermer.Text = "Fermer"
        Me.buttonFermer.UseVisualStyleBackColor = True
        '
        'codeFenExo16
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(357, 247)
        Me.Controls.Add(Me.buttonFermer)
        Me.Controls.Add(Me.labelDateNaissance)
        Me.Controls.Add(Me.labelPrenom)
        Me.Controls.Add(Me.labelNom)
        Me.Controls.Add(Me.textDateDeNaissance)
        Me.Controls.Add(Me.textPrenom)
        Me.Controls.Add(Me.textNom)
        Me.Name = "codeFenExo16"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Exercice 16 - Récapitulatif d'une personne"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents textNom As TextBox
    Friend WithEvents textPrenom As TextBox
    Friend WithEvents textDateDeNaissance As TextBox
    Friend WithEvents labelNom As Label
    Friend WithEvents labelPrenom As Label
    Friend WithEvents labelDateNaissance As Label
    Friend WithEvents buttonFermer As Button
End Class
