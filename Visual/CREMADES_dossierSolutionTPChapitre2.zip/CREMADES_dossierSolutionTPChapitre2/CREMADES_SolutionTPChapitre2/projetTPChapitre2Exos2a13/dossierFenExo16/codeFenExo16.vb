﻿Public Class codeFenExo16
    Private Sub buttonFermer_Click(sender As Object, e As EventArgs) Handles buttonFermer.Click
        Close()
    End Sub

    Private Sub textDateDeNaissance_KeyPress(sender As Object, e As KeyPressEventArgs) Handles textDateDeNaissance.KeyPress
        If e.KeyChar = Chr(13) Then
            Dim Nom As String = textNom.Text
            Dim Prenom As String = textPrenom.Text
            Dim DateNaissance As String = textDateDeNaissance.Text
            Dim NaissJ As Double
            Dim JourJ As Double
            Dim age As Double
            Dim dateNow As Double

            NaissJ = Convert.ToDouble(DateNaissance.Substring(0, 2))
            NaissJ = NaissJ + (Convert.ToDouble(DateNaissance.Substring(3, 2)) * (365.25 / 12))
            NaissJ = NaissJ + (Convert.ToDouble(DateNaissance.Substring(6, 4)) * 365.25)
            dateNow = DateTime.Now.Day + (DateTime.Now.Month * (365.25 / 12)) + (DateTime.Now.Year * 365.25)
            age = dateNow - NaissJ

            'Arrondi à l'entier en dessous
            age = Math.Floor(age / 365.25)

            MessageBox.Show("Vous vous appelez " & Prenom(0) & "." & Nom & " et vous avez " & age & " ans.")

        End If
    End Sub

    Private Sub labelDateNaissance_Click(sender As Object, e As EventArgs) Handles labelDateNaissance.Click

    End Sub
End Class