﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class fenExo5
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Fermer = New System.Windows.Forms.Button()
        Me.labNb1 = New System.Windows.Forms.Label()
        Me.labNb2 = New System.Windows.Forms.Label()
        Me.textNb1 = New System.Windows.Forms.TextBox()
        Me.textNb2 = New System.Windows.Forms.TextBox()
        Me.bPermut = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Fermer
        '
        Me.Fermer.Location = New System.Drawing.Point(299, 244)
        Me.Fermer.Name = "Fermer"
        Me.Fermer.Size = New System.Drawing.Size(75, 23)
        Me.Fermer.TabIndex = 0
        Me.Fermer.Text = "Fermer"
        Me.Fermer.UseVisualStyleBackColor = True
        '
        'labNb1
        '
        Me.labNb1.AutoSize = True
        Me.labNb1.Location = New System.Drawing.Point(61, 86)
        Me.labNb1.Name = "labNb1"
        Me.labNb1.Size = New System.Drawing.Size(86, 13)
        Me.labNb1.TabIndex = 1
        Me.labNb1.Text = "Premier nombre :"
        '
        'labNb2
        '
        Me.labNb2.AutoSize = True
        Me.labNb2.Location = New System.Drawing.Point(61, 155)
        Me.labNb2.Name = "labNb2"
        Me.labNb2.Size = New System.Drawing.Size(98, 13)
        Me.labNb2.TabIndex = 2
        Me.labNb2.Text = "Deuxième nombre :"
        '
        'textNb1
        '
        Me.textNb1.Location = New System.Drawing.Point(196, 86)
        Me.textNb1.Name = "textNb1"
        Me.textNb1.Size = New System.Drawing.Size(100, 20)
        Me.textNb1.TabIndex = 3
        '
        'textNb2
        '
        Me.textNb2.Location = New System.Drawing.Point(196, 147)
        Me.textNb2.Name = "textNb2"
        Me.textNb2.Size = New System.Drawing.Size(100, 20)
        Me.textNb2.TabIndex = 4
        '
        'bPermut
        '
        Me.bPermut.Location = New System.Drawing.Point(169, 208)
        Me.bPermut.Name = "bPermut"
        Me.bPermut.Size = New System.Drawing.Size(75, 23)
        Me.bPermut.TabIndex = 5
        Me.bPermut.Text = "Permuter"
        Me.bPermut.UseVisualStyleBackColor = True
        '
        'fenExo5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(407, 306)
        Me.Controls.Add(Me.bPermut)
        Me.Controls.Add(Me.textNb2)
        Me.Controls.Add(Me.textNb1)
        Me.Controls.Add(Me.labNb2)
        Me.Controls.Add(Me.labNb1)
        Me.Controls.Add(Me.Fermer)
        Me.Name = "fenExo5"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Exercice 5 - Permutation de deux nombres"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Fermer As Button
    Friend WithEvents labNb1 As Label
    Friend WithEvents labNb2 As Label
    Friend WithEvents textNb1 As TextBox
    Friend WithEvents textNb2 As TextBox
    Friend WithEvents bPermut As Button
End Class
