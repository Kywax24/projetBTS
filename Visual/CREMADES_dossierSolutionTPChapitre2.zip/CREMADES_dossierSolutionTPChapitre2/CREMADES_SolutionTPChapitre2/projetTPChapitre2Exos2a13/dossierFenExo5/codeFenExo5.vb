﻿Public Class fenExo5
    Private Sub bPermut_Click(sender As Object, e As EventArgs) Handles bPermut.Click
        Dim x As String

        x = textNb2.Text
        textNb2.Text = textNb1.Text
        textNb1.Text = x

    End Sub
    Private Sub Fermer_Click(sender As Object, e As EventArgs) Handles Fermer.Click
        Close()
    End Sub
End Class