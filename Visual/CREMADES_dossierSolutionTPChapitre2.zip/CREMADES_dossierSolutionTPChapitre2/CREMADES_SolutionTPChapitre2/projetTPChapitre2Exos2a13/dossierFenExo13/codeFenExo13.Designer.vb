﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class codeFenExo13
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.textSomme = New System.Windows.Forms.TextBox()
        Me.textNb100 = New System.Windows.Forms.TextBox()
        Me.textNb50 = New System.Windows.Forms.TextBox()
        Me.textNb10 = New System.Windows.Forms.TextBox()
        Me.textNb5 = New System.Windows.Forms.TextBox()
        Me.textNb1 = New System.Windows.Forms.TextBox()
        Me.boutonFermer = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'textSomme
        '
        Me.textSomme.Location = New System.Drawing.Point(186, 55)
        Me.textSomme.Name = "textSomme"
        Me.textSomme.Size = New System.Drawing.Size(100, 20)
        Me.textSomme.TabIndex = 0
        '
        'textNb100
        '
        Me.textNb100.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.textNb100.Location = New System.Drawing.Point(186, 124)
        Me.textNb100.Name = "textNb100"
        Me.textNb100.ReadOnly = True
        Me.textNb100.Size = New System.Drawing.Size(100, 20)
        Me.textNb100.TabIndex = 1
        '
        'textNb50
        '
        Me.textNb50.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.textNb50.Location = New System.Drawing.Point(186, 150)
        Me.textNb50.Name = "textNb50"
        Me.textNb50.ReadOnly = True
        Me.textNb50.Size = New System.Drawing.Size(100, 20)
        Me.textNb50.TabIndex = 2
        '
        'textNb10
        '
        Me.textNb10.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.textNb10.Location = New System.Drawing.Point(186, 176)
        Me.textNb10.Name = "textNb10"
        Me.textNb10.ReadOnly = True
        Me.textNb10.Size = New System.Drawing.Size(100, 20)
        Me.textNb10.TabIndex = 3
        '
        'textNb5
        '
        Me.textNb5.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.textNb5.Location = New System.Drawing.Point(186, 202)
        Me.textNb5.Name = "textNb5"
        Me.textNb5.ReadOnly = True
        Me.textNb5.Size = New System.Drawing.Size(100, 20)
        Me.textNb5.TabIndex = 4
        '
        'textNb1
        '
        Me.textNb1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.textNb1.Location = New System.Drawing.Point(186, 228)
        Me.textNb1.Name = "textNb1"
        Me.textNb1.ReadOnly = True
        Me.textNb1.Size = New System.Drawing.Size(100, 20)
        Me.textNb1.TabIndex = 5
        '
        'boutonFermer
        '
        Me.boutonFermer.Location = New System.Drawing.Point(242, 291)
        Me.boutonFermer.Name = "boutonFermer"
        Me.boutonFermer.Size = New System.Drawing.Size(75, 23)
        Me.boutonFermer.TabIndex = 6
        Me.boutonFermer.Text = "Fermer"
        Me.boutonFermer.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(59, 58)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(121, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Somme à décomposer : "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(41, 127)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(139, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Nombre de billet(s) de 100 : "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(47, 153)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(133, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Nombre de billet(s) de 50 : "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(47, 179)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(133, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Nombre de billet(s) de 50 : "
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(53, 205)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(127, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Nombre de billet(s) de 5 : "
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(53, 231)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(127, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Nombre de billet(s) de 1 : "
        '
        'codeFenExo13
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(345, 334)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.boutonFermer)
        Me.Controls.Add(Me.textNb1)
        Me.Controls.Add(Me.textNb5)
        Me.Controls.Add(Me.textNb10)
        Me.Controls.Add(Me.textNb50)
        Me.Controls.Add(Me.textNb100)
        Me.Controls.Add(Me.textSomme)
        Me.Name = "codeFenExo13"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Exercice 13 - Décomposition d'une somme d'argent"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents textSomme As TextBox
    Friend WithEvents textNb100 As TextBox
    Friend WithEvents textNb50 As TextBox
    Friend WithEvents textNb10 As TextBox
    Friend WithEvents textNb5 As TextBox
    Friend WithEvents textNb1 As TextBox
    Friend WithEvents boutonFermer As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
End Class
