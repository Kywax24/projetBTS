﻿Public Class codeFenExo13

    Private Sub textSomme_KeyPress(sender As Object, e As KeyPressEventArgs) Handles textSomme.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            Dim somme As Int16
            somme = Convert.ToInt16(textSomme.Text)

            textNb100.Text = somme \ 100
            somme = somme Mod 100
            textNb50.Text = somme \ 50
            somme = somme Mod 50
            textNb10.Text = somme \ 10
            somme = somme Mod 10
            textNb5.Text = somme \ 5
            somme = somme Mod 5
            textNb1.Text = somme
        End If

    End Sub

    Private Sub boutonFermer_Click(sender As Object, e As EventArgs) Handles boutonFermer.Click
        Close()
    End Sub
End Class