﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class codeFenExo14
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.motSecr = New System.Windows.Forms.TextBox()
        Me.repCodeSecr = New System.Windows.Forms.TextBox()
        Me.fermer = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(46, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(78, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Mot à traduire :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(46, 95)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Mot en ASCII :"
        '
        'motSecr
        '
        Me.motSecr.Location = New System.Drawing.Point(156, 30)
        Me.motSecr.Name = "motSecr"
        Me.motSecr.Size = New System.Drawing.Size(100, 20)
        Me.motSecr.TabIndex = 2
        '
        'repCodeSecr
        '
        Me.repCodeSecr.Location = New System.Drawing.Point(156, 92)
        Me.repCodeSecr.Name = "repCodeSecr"
        Me.repCodeSecr.Size = New System.Drawing.Size(100, 20)
        Me.repCodeSecr.TabIndex = 3
        '
        'fermer
        '
        Me.fermer.Location = New System.Drawing.Point(156, 151)
        Me.fermer.Name = "fermer"
        Me.fermer.Size = New System.Drawing.Size(100, 23)
        Me.fermer.TabIndex = 4
        Me.fermer.Text = "Fermer"
        Me.fermer.UseVisualStyleBackColor = True
        '
        'codeFenExo14
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(317, 203)
        Me.Controls.Add(Me.fermer)
        Me.Controls.Add(Me.repCodeSecr)
        Me.Controls.Add(Me.motSecr)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "codeFenExo14"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Exercice 14 - Traduction code ASCII"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents motSecr As TextBox
    Friend WithEvents repCodeSecr As TextBox
    Friend WithEvents fermer As Button
End Class
