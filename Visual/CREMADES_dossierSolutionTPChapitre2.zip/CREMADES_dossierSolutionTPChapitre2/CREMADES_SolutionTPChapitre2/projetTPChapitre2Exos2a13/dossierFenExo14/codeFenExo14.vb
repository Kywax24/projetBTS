﻿Public Class codeFenExo14
    Private Sub fermer_Click(sender As Object, e As EventArgs) Handles fermer.Click
        Me.Close()
    End Sub


    Private Sub CalculerEtAfficherMotSecr()
        If Not String.IsNullOrWhiteSpace(motSecr.Text) Then

            Dim codeAscii1 As Integer = Asc(motSecr.Text.Chars(0))
            Dim codeAscii2 As Integer = Asc(motSecr.Text.Chars(1))
            Dim codeAscii3 As Integer = Asc(motSecr.Text.Chars(2))
            Dim codeAscii4 As Integer = Asc(motSecr.Text.Chars(3))

            repCodeSecr.Text = codeAscii1 & codeAscii2 & codeAscii3 & codeAscii4

        Else
            repCodeSecr.Text = ""
        End If

    End Sub

    Private Sub motSecr_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles motSecr.KeyPress
        If e.KeyChar = Chr(13) Then
            CalculerEtAfficherMotSecr()
        End If
    End Sub
    Private Sub motSecr_Leave(sender As Object, e As EventArgs) Handles motSecr.Leave
        CalculerEtAfficherMotSecr()
    End Sub

End Class