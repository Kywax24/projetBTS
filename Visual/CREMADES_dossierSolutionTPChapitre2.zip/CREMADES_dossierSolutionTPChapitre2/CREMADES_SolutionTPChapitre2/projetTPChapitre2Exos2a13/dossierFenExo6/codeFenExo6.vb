﻿Public Class codeFenExo6
    Private Sub bPermut_Click(sender As Object, e As EventArgs) Handles bPermut.Click

        Dim x As Int16 = textNb1.Text
        Dim y As Int16 = textNb2.Text


        x = x + y
        y = x - y
        x = x - y

        textNb1.Text = x
        textNb2.Text = y

    End Sub
    Private Sub Fermer_Click(sender As Object, e As EventArgs) Handles Fermer.Click
        Close()
    End Sub
End Class