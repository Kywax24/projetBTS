﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class codeFenExo6
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.bPermut = New System.Windows.Forms.Button()
        Me.textNb2 = New System.Windows.Forms.TextBox()
        Me.textNb1 = New System.Windows.Forms.TextBox()
        Me.labNb2 = New System.Windows.Forms.Label()
        Me.labNb1 = New System.Windows.Forms.Label()
        Me.Fermer = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'bPermut
        '
        Me.bPermut.Location = New System.Drawing.Point(160, 169)
        Me.bPermut.Name = "bPermut"
        Me.bPermut.Size = New System.Drawing.Size(75, 23)
        Me.bPermut.TabIndex = 11
        Me.bPermut.Text = "Permuter"
        Me.bPermut.UseVisualStyleBackColor = True
        '
        'textNb2
        '
        Me.textNb2.Location = New System.Drawing.Point(187, 108)
        Me.textNb2.Name = "textNb2"
        Me.textNb2.Size = New System.Drawing.Size(100, 20)
        Me.textNb2.TabIndex = 10
        '
        'textNb1
        '
        Me.textNb1.Location = New System.Drawing.Point(187, 47)
        Me.textNb1.Name = "textNb1"
        Me.textNb1.Size = New System.Drawing.Size(100, 20)
        Me.textNb1.TabIndex = 9
        '
        'labNb2
        '
        Me.labNb2.AutoSize = True
        Me.labNb2.Location = New System.Drawing.Point(52, 116)
        Me.labNb2.Name = "labNb2"
        Me.labNb2.Size = New System.Drawing.Size(98, 13)
        Me.labNb2.TabIndex = 8
        Me.labNb2.Text = "Deuxième nombre :"
        '
        'labNb1
        '
        Me.labNb1.AutoSize = True
        Me.labNb1.Location = New System.Drawing.Point(52, 47)
        Me.labNb1.Name = "labNb1"
        Me.labNb1.Size = New System.Drawing.Size(86, 13)
        Me.labNb1.TabIndex = 7
        Me.labNb1.Text = "Premier nombre :"
        '
        'Fermer
        '
        Me.Fermer.Location = New System.Drawing.Point(290, 205)
        Me.Fermer.Name = "Fermer"
        Me.Fermer.Size = New System.Drawing.Size(75, 23)
        Me.Fermer.TabIndex = 6
        Me.Fermer.Text = "Fermer"
        Me.Fermer.UseVisualStyleBackColor = True
        '
        'codeFenExo6
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(382, 240)
        Me.Controls.Add(Me.bPermut)
        Me.Controls.Add(Me.textNb2)
        Me.Controls.Add(Me.textNb1)
        Me.Controls.Add(Me.labNb2)
        Me.Controls.Add(Me.labNb1)
        Me.Controls.Add(Me.Fermer)
        Me.Name = "codeFenExo6"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Exercice 6 - Permutter deux nombres par calcul"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents bPermut As Button
    Friend WithEvents textNb2 As TextBox
    Friend WithEvents textNb1 As TextBox
    Friend WithEvents labNb2 As Label
    Friend WithEvents labNb1 As Label
    Friend WithEvents Fermer As Button
End Class
