﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class fenAccueil
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FichierToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QuitterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NumériquesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExercicesNumériquesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Exercice2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Exercice5ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Exercice6ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Exercice7ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Exercice8ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Exercice9ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Exercice10ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Exercice11ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Exercice12ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Exercice13ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChaînesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExercicesChaînesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Exercice14ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Exercice15ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Exercice16ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AideToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FichierToolStripMenuItem, Me.NumériquesToolStripMenuItem, Me.ChaînesToolStripMenuItem, Me.AideToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(506, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FichierToolStripMenuItem
        '
        Me.FichierToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.QuitterToolStripMenuItem})
        Me.FichierToolStripMenuItem.Name = "FichierToolStripMenuItem"
        Me.FichierToolStripMenuItem.Size = New System.Drawing.Size(54, 20)
        Me.FichierToolStripMenuItem.Text = "Fichier"
        '
        'QuitterToolStripMenuItem
        '
        Me.QuitterToolStripMenuItem.Name = "QuitterToolStripMenuItem"
        Me.QuitterToolStripMenuItem.Size = New System.Drawing.Size(111, 22)
        Me.QuitterToolStripMenuItem.Text = "Quitter"
        '
        'NumériquesToolStripMenuItem
        '
        Me.NumériquesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExercicesNumériquesToolStripMenuItem})
        Me.NumériquesToolStripMenuItem.Name = "NumériquesToolStripMenuItem"
        Me.NumériquesToolStripMenuItem.Size = New System.Drawing.Size(84, 20)
        Me.NumériquesToolStripMenuItem.Text = "Numériques"
        '
        'ExercicesNumériquesToolStripMenuItem
        '
        Me.ExercicesNumériquesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Exercice2ToolStripMenuItem, Me.Exercice5ToolStripMenuItem, Me.Exercice6ToolStripMenuItem, Me.Exercice7ToolStripMenuItem, Me.Exercice8ToolStripMenuItem, Me.Exercice9ToolStripMenuItem, Me.Exercice10ToolStripMenuItem, Me.Exercice11ToolStripMenuItem, Me.Exercice12ToolStripMenuItem, Me.Exercice13ToolStripMenuItem})
        Me.ExercicesNumériquesToolStripMenuItem.Name = "ExercicesNumériquesToolStripMenuItem"
        Me.ExercicesNumériquesToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.ExercicesNumériquesToolStripMenuItem.Text = "Exercices numériques"
        '
        'Exercice2ToolStripMenuItem
        '
        Me.Exercice2ToolStripMenuItem.Name = "Exercice2ToolStripMenuItem"
        Me.Exercice2ToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.Exercice2ToolStripMenuItem.Text = "Exercice 2"
        '
        'Exercice5ToolStripMenuItem
        '
        Me.Exercice5ToolStripMenuItem.Name = "Exercice5ToolStripMenuItem"
        Me.Exercice5ToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.Exercice5ToolStripMenuItem.Text = "Exercice 5"
        '
        'Exercice6ToolStripMenuItem
        '
        Me.Exercice6ToolStripMenuItem.Name = "Exercice6ToolStripMenuItem"
        Me.Exercice6ToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.Exercice6ToolStripMenuItem.Text = "Exercice 6"
        '
        'Exercice7ToolStripMenuItem
        '
        Me.Exercice7ToolStripMenuItem.Name = "Exercice7ToolStripMenuItem"
        Me.Exercice7ToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.Exercice7ToolStripMenuItem.Text = "Exercice 7"
        '
        'Exercice8ToolStripMenuItem
        '
        Me.Exercice8ToolStripMenuItem.Name = "Exercice8ToolStripMenuItem"
        Me.Exercice8ToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.Exercice8ToolStripMenuItem.Text = "Exercice 8"
        '
        'Exercice9ToolStripMenuItem
        '
        Me.Exercice9ToolStripMenuItem.Name = "Exercice9ToolStripMenuItem"
        Me.Exercice9ToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.Exercice9ToolStripMenuItem.Text = "Exercice 9"
        '
        'Exercice10ToolStripMenuItem
        '
        Me.Exercice10ToolStripMenuItem.Name = "Exercice10ToolStripMenuItem"
        Me.Exercice10ToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.Exercice10ToolStripMenuItem.Text = "Exercice 10"
        '
        'Exercice11ToolStripMenuItem
        '
        Me.Exercice11ToolStripMenuItem.Name = "Exercice11ToolStripMenuItem"
        Me.Exercice11ToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.Exercice11ToolStripMenuItem.Text = "Exercice 11"
        '
        'Exercice12ToolStripMenuItem
        '
        Me.Exercice12ToolStripMenuItem.Name = "Exercice12ToolStripMenuItem"
        Me.Exercice12ToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.Exercice12ToolStripMenuItem.Text = "Exercice 12"
        '
        'Exercice13ToolStripMenuItem
        '
        Me.Exercice13ToolStripMenuItem.Name = "Exercice13ToolStripMenuItem"
        Me.Exercice13ToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.Exercice13ToolStripMenuItem.Text = "Exercice 13"
        '
        'ChaînesToolStripMenuItem
        '
        Me.ChaînesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExercicesChaînesToolStripMenuItem})
        Me.ChaînesToolStripMenuItem.Name = "ChaînesToolStripMenuItem"
        Me.ChaînesToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.ChaînesToolStripMenuItem.Text = "Chaînes"
        '
        'ExercicesChaînesToolStripMenuItem
        '
        Me.ExercicesChaînesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Exercice14ToolStripMenuItem, Me.Exercice15ToolStripMenuItem, Me.Exercice16ToolStripMenuItem})
        Me.ExercicesChaînesToolStripMenuItem.Name = "ExercicesChaînesToolStripMenuItem"
        Me.ExercicesChaînesToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.ExercicesChaînesToolStripMenuItem.Text = "Exercices chaînes"
        '
        'Exercice14ToolStripMenuItem
        '
        Me.Exercice14ToolStripMenuItem.Name = "Exercice14ToolStripMenuItem"
        Me.Exercice14ToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.Exercice14ToolStripMenuItem.Text = "Exercice 14"
        '
        'Exercice15ToolStripMenuItem
        '
        Me.Exercice15ToolStripMenuItem.Name = "Exercice15ToolStripMenuItem"
        Me.Exercice15ToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.Exercice15ToolStripMenuItem.Text = "Exercice 15"
        '
        'Exercice16ToolStripMenuItem
        '
        Me.Exercice16ToolStripMenuItem.Name = "Exercice16ToolStripMenuItem"
        Me.Exercice16ToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.Exercice16ToolStripMenuItem.Text = "Exercice 16"
        '
        'AideToolStripMenuItem
        '
        Me.AideToolStripMenuItem.Name = "AideToolStripMenuItem"
        Me.AideToolStripMenuItem.Size = New System.Drawing.Size(59, 20)
        Me.AideToolStripMenuItem.Text = "Aide (?)"
        '
        'fenAccueil
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(506, 103)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Location = New System.Drawing.Point(500, 500)
        Me.Name = "fenAccueil"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Logiciels bureautiques - Accueil"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FichierToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents QuitterToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NumériquesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExercicesNumériquesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ChaînesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AideToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Exercice2ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Exercice5ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Exercice6ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Exercice7ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Exercice8ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Exercice9ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Exercice10ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Exercice11ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Exercice12ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Exercice13ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExercicesChaînesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Exercice14ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Exercice15ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Exercice16ToolStripMenuItem As ToolStripMenuItem
End Class
