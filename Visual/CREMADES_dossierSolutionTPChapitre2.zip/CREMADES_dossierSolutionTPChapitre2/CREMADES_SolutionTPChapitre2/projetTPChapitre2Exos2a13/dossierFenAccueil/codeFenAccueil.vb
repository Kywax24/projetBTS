﻿Public Class fenAccueil
    Private Sub QuitterToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles QuitterToolStripMenuItem.Click
        Close()
    End Sub

    Private Sub Exercice2ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Exercice2ToolStripMenuItem.Click
        fenExo2.Show()
    End Sub

    Private Sub Exercice5ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Exercice5ToolStripMenuItem.Click
        fenExo5.Show()
    End Sub

    Private Sub Exercice6ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Exercice6ToolStripMenuItem.Click
        codeFenExo6.Show()
    End Sub

    Private Sub Exercice7ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Exercice7ToolStripMenuItem.Click
        codeFenExo7.Show()
    End Sub

    Private Sub Exercice13ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Exercice13ToolStripMenuItem.Click
        codeFenExo13.Show()
    End Sub

    Private Sub Exercice14ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Exercice14ToolStripMenuItem.Click
        codeFenExo14.Show()
    End Sub

    Private Sub Exercice15ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Exercice15ToolStripMenuItem.Click
        codeFenExo15.Show()
    End Sub

    Private Sub Exercice16ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Exercice16ToolStripMenuItem.Click
        codeFenExo16.Show()
    End Sub

    Private Sub AideToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AideToolStripMenuItem.Click
        fenAide.Show()
    End Sub
End Class