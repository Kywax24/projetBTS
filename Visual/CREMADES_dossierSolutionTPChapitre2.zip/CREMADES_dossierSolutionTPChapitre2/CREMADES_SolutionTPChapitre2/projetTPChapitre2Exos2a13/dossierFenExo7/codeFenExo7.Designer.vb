﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class codeFenExo7
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.note1 = New System.Windows.Forms.TextBox()
        Me.coef1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.coef2 = New System.Windows.Forms.TextBox()
        Me.note2 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.coef3 = New System.Windows.Forms.TextBox()
        Me.note3 = New System.Windows.Forms.TextBox()
        Me.bFermer = New System.Windows.Forms.Button()
        Me.bCalculer = New System.Windows.Forms.Button()
        Me.moyenneTotale = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'note1
        '
        Me.note1.Location = New System.Drawing.Point(94, 36)
        Me.note1.Name = "note1"
        Me.note1.Size = New System.Drawing.Size(100, 20)
        Me.note1.TabIndex = 0
        '
        'coef1
        '
        Me.coef1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.coef1.Location = New System.Drawing.Point(334, 36)
        Me.coef1.Name = "coef1"
        Me.coef1.ReadOnly = True
        Me.coef1.Size = New System.Drawing.Size(100, 20)
        Me.coef1.TabIndex = 1
        Me.coef1.Text = "3"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Note 1 :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(242, 39)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Coefficient 1 :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(242, 81)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 13)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Coefficient 2 :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(27, 81)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Note 2 :"
        '
        'coef2
        '
        Me.coef2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.coef2.Location = New System.Drawing.Point(334, 78)
        Me.coef2.Name = "coef2"
        Me.coef2.ReadOnly = True
        Me.coef2.Size = New System.Drawing.Size(100, 20)
        Me.coef2.TabIndex = 9
        Me.coef2.Text = "4"
        '
        'note2
        '
        Me.note2.Location = New System.Drawing.Point(94, 78)
        Me.note2.Name = "note2"
        Me.note2.Size = New System.Drawing.Size(100, 20)
        Me.note2.TabIndex = 8
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(242, 123)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 13)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "Coefficient 3 :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(27, 123)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 13)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Note 3 :"
        '
        'coef3
        '
        Me.coef3.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.coef3.Location = New System.Drawing.Point(334, 120)
        Me.coef3.Name = "coef3"
        Me.coef3.ReadOnly = True
        Me.coef3.Size = New System.Drawing.Size(100, 20)
        Me.coef3.TabIndex = 13
        Me.coef3.Text = "2"
        '
        'note3
        '
        Me.note3.Location = New System.Drawing.Point(94, 120)
        Me.note3.Name = "note3"
        Me.note3.Size = New System.Drawing.Size(100, 20)
        Me.note3.TabIndex = 12
        '
        'bFermer
        '
        Me.bFermer.Location = New System.Drawing.Point(430, 254)
        Me.bFermer.Name = "bFermer"
        Me.bFermer.Size = New System.Drawing.Size(75, 23)
        Me.bFermer.TabIndex = 16
        Me.bFermer.Text = "Fermer"
        Me.bFermer.UseVisualStyleBackColor = True
        '
        'bCalculer
        '
        Me.bCalculer.Location = New System.Drawing.Point(239, 168)
        Me.bCalculer.Name = "bCalculer"
        Me.bCalculer.Size = New System.Drawing.Size(75, 23)
        Me.bCalculer.TabIndex = 17
        Me.bCalculer.Text = "Calculer"
        Me.bCalculer.UseVisualStyleBackColor = True
        '
        'moyenneTotale
        '
        Me.moyenneTotale.Location = New System.Drawing.Point(274, 213)
        Me.moyenneTotale.Name = "moyenneTotale"
        Me.moyenneTotale.Size = New System.Drawing.Size(100, 20)
        Me.moyenneTotale.TabIndex = 18
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(182, 216)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(86, 13)
        Me.Label7.TabIndex = 19
        Me.Label7.Text = "Moyenne totale :"
        '
        'codeFenExo7
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(525, 297)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.moyenneTotale)
        Me.Controls.Add(Me.bCalculer)
        Me.Controls.Add(Me.bFermer)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.coef3)
        Me.Controls.Add(Me.note3)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.coef2)
        Me.Controls.Add(Me.note2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.coef1)
        Me.Controls.Add(Me.note1)
        Me.Name = "codeFenExo7"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Exercice 7 - Calculer une moyenne"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents note1 As TextBox
    Friend WithEvents coef1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents coef2 As TextBox
    Friend WithEvents note2 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents coef3 As TextBox
    Friend WithEvents note3 As TextBox
    Friend WithEvents bFermer As Button
    Friend WithEvents bCalculer As Button
    Friend WithEvents moyenneTotale As TextBox
    Friend WithEvents Label7 As Label
End Class
