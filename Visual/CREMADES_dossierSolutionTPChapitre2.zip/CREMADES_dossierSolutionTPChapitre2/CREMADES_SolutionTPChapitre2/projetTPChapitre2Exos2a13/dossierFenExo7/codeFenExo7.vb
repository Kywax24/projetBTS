﻿Public Class codeFenExo7
    Private Sub bCalculer_Click(sender As Object, e As EventArgs) Handles bCalculer.Click

        moyenneTotale.Text = (Convert.ToInt16(note1.Text) * Convert.ToInt16(coef1.Text) + Convert.ToInt16(note2.Text) * Convert.ToInt16(coef2.Text) + Convert.ToInt16(note3.Text) * Convert.ToInt16(coef3.Text)) / (Convert.ToInt16(coef1.Text) + Convert.ToInt16(coef2.Text) + Convert.ToInt16(coef3.Text))

    End Sub

    Private Sub bFermer_Click(sender As Object, e As EventArgs) Handles bFermer.Click
        Close()
    End Sub
End Class