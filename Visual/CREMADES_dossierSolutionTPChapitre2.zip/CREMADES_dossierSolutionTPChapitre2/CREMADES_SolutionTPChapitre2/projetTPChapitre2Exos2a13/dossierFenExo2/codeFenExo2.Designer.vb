﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class fenExo2
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button_Fermer = New System.Windows.Forms.Button()
        Me.PrixPoint = New System.Windows.Forms.TextBox()
        Me.TauxRetenue = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Indice = New System.Windows.Forms.TextBox()
        Me.Button_Calculer = New System.Windows.Forms.Button()
        Me.SalaireBrut = New System.Windows.Forms.TextBox()
        Me.SalaireNet = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Button_Fermer
        '
        Me.Button_Fermer.Location = New System.Drawing.Point(463, 314)
        Me.Button_Fermer.Name = "Button_Fermer"
        Me.Button_Fermer.Size = New System.Drawing.Size(75, 23)
        Me.Button_Fermer.TabIndex = 0
        Me.Button_Fermer.Text = "Fermer"
        Me.Button_Fermer.UseVisualStyleBackColor = True
        '
        'PrixPoint
        '
        Me.PrixPoint.Location = New System.Drawing.Point(248, 112)
        Me.PrixPoint.Name = "PrixPoint"
        Me.PrixPoint.ReadOnly = True
        Me.PrixPoint.Size = New System.Drawing.Size(100, 20)
        Me.PrixPoint.TabIndex = 1
        Me.PrixPoint.Text = "3.25"
        '
        'TauxRetenue
        '
        Me.TauxRetenue.Location = New System.Drawing.Point(248, 158)
        Me.TauxRetenue.Name = "TauxRetenue"
        Me.TauxRetenue.ReadOnly = True
        Me.TauxRetenue.Size = New System.Drawing.Size(100, 20)
        Me.TauxRetenue.TabIndex = 2
        Me.TauxRetenue.Text = "0.2"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(126, 115)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Prix du point :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(126, 161)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(91, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Taux de retenue :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.Label3.Location = New System.Drawing.Point(126, 70)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(83, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Indice (à saisir) :"
        '
        'Indice
        '
        Me.Indice.Location = New System.Drawing.Point(248, 67)
        Me.Indice.Name = "Indice"
        Me.Indice.Size = New System.Drawing.Size(100, 20)
        Me.Indice.TabIndex = 6
        '
        'Button_Calculer
        '
        Me.Button_Calculer.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.Button_Calculer.Location = New System.Drawing.Point(220, 216)
        Me.Button_Calculer.Name = "Button_Calculer"
        Me.Button_Calculer.Size = New System.Drawing.Size(75, 23)
        Me.Button_Calculer.TabIndex = 7
        Me.Button_Calculer.Text = "Calculer"
        Me.Button_Calculer.UseVisualStyleBackColor = True
        '
        'SalaireBrut
        '
        Me.SalaireBrut.Location = New System.Drawing.Point(109, 270)
        Me.SalaireBrut.Name = "SalaireBrut"
        Me.SalaireBrut.Size = New System.Drawing.Size(100, 20)
        Me.SalaireBrut.TabIndex = 8
        '
        'SalaireNet
        '
        Me.SalaireNet.Location = New System.Drawing.Point(362, 270)
        Me.SalaireNet.Name = "SalaireNet"
        Me.SalaireNet.Size = New System.Drawing.Size(100, 20)
        Me.SalaireNet.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(37, 273)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(66, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Salaire brut :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(293, 273)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(63, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Salaire net :"
        '
        'fenExo2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(561, 365)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.SalaireNet)
        Me.Controls.Add(Me.SalaireBrut)
        Me.Controls.Add(Me.Button_Calculer)
        Me.Controls.Add(Me.Indice)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TauxRetenue)
        Me.Controls.Add(Me.PrixPoint)
        Me.Controls.Add(Me.Button_Fermer)
        Me.Name = "fenExo2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Exercice 2 - Calculer le salaire brut et net"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button_Fermer As Button
    Friend WithEvents PrixPoint As TextBox
    Friend WithEvents TauxRetenue As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Indice As TextBox
    Friend WithEvents Button_Calculer As Button
    Friend WithEvents SalaireBrut As TextBox
    Friend WithEvents SalaireNet As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
End Class
