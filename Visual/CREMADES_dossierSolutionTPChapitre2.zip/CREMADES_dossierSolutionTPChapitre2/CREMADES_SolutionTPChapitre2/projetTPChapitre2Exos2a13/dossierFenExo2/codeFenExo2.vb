﻿Public Class fenExo2
    Private Sub Button_Calculer_Click(sender As Object, e As EventArgs) Handles Button_Calculer.Click
        SalaireBrut.Text = Convert.ToString(Convert.ToInt16(Indice.Text) * 3.25)
        SalaireNet.Text = Convert.ToString(SalaireBrut.Text * (1 - 0.2))
    End Sub

    Private Sub Button_Fermer_Click(sender As Object, e As EventArgs) Handles Button_Fermer.Click
        Close()
    End Sub
End Class
