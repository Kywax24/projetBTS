﻿Public Class codeFenExo15

    Private Sub fermer_Click(sender As Object, e As EventArgs) Handles fermer.Click
        Close()
    End Sub

    Private Sub buttonCrypter_Click(sender As Object, e As EventArgs) Handles buttonCrypter.Click
        Dim mot As String = motACrypter.Text.ToLower() ' Convertir le mot en minuscules
        Dim motCrypte As String = CrypterMot(mot) ' Appeler la fonction de cryptage
        motApresCryptage.Text = motCrypte ' Afficher le mot crypté
    End Sub

    Private Function CrypterMot(mot As String) As String
        Dim alphabet As String = "abcdefghijklmnopqrstuvwxyz"
        Dim motInverse As String = ""
        Dim motCrypte As String = ""

        ' Inverser le mot
        For i As Integer = mot.Length - 1 To 0 Step -1
            motInverse += mot(i)
        Next

        ' Crypter le mot inversé
        For Each lettre As Char In motInverse
            Dim position As Integer = 0
            For j As Integer = 0 To alphabet.Length - 1
                If alphabet(j) = lettre Then
                    position = j
                    Exit For
                End If
            Next
            Dim lettreSymetrique As Char = alphabet(alphabet.Length - 1 - position)
            motCrypte += lettre & lettreSymetrique
        Next

        Return motCrypte
    End Function
End Class