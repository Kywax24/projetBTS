﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class codeFenExo15
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.motACrypter = New System.Windows.Forms.TextBox()
        Me.motApresCryptage = New System.Windows.Forms.TextBox()
        Me.fermer = New System.Windows.Forms.Button()
        Me.buttonCrypter = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(36, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Mot à crypter :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(36, 91)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Mot crypté :"
        '
        'motACrypter
        '
        Me.motACrypter.Location = New System.Drawing.Point(190, 37)
        Me.motACrypter.Name = "motACrypter"
        Me.motACrypter.Size = New System.Drawing.Size(100, 20)
        Me.motACrypter.TabIndex = 2
        '
        'motApresCryptage
        '
        Me.motApresCryptage.Location = New System.Drawing.Point(190, 88)
        Me.motApresCryptage.Name = "motApresCryptage"
        Me.motApresCryptage.Size = New System.Drawing.Size(100, 20)
        Me.motApresCryptage.TabIndex = 3
        '
        'fermer
        '
        Me.fermer.Location = New System.Drawing.Point(190, 142)
        Me.fermer.Name = "fermer"
        Me.fermer.Size = New System.Drawing.Size(100, 23)
        Me.fermer.TabIndex = 5
        Me.fermer.Text = "Fermer"
        Me.fermer.UseVisualStyleBackColor = True
        '
        'buttonCrypter
        '
        Me.buttonCrypter.Location = New System.Drawing.Point(39, 142)
        Me.buttonCrypter.Name = "buttonCrypter"
        Me.buttonCrypter.Size = New System.Drawing.Size(100, 23)
        Me.buttonCrypter.TabIndex = 4
        Me.buttonCrypter.Text = "Crypter"
        Me.buttonCrypter.UseVisualStyleBackColor = True
        '
        'codeFenExo15
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(322, 191)
        Me.Controls.Add(Me.buttonCrypter)
        Me.Controls.Add(Me.fermer)
        Me.Controls.Add(Me.motApresCryptage)
        Me.Controls.Add(Me.motACrypter)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "codeFenExo15"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Exercice 15 - Crypter un mot"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents motACrypter As TextBox
    Friend WithEvents motApresCryptage As TextBox
    Friend WithEvents fermer As Button
    Friend WithEvents buttonCrypter As Button
End Class
