﻿Module Exercice2

    Sub Main()
        Dim Indice As Double
        Dim PrixPoint As Double
        Dim TauxBrut As Double
        Dim SalaireBrut As Double
        Dim SalaireNet As Double

        Console.WriteLine("Calculer le salaire")
        PrixPoint = 3.25
        TauxBrut = 0.2
        Console.Write("Saisissez l'indice en nombre de points : ")
        Indice = Console.ReadLine()

        SalaireBrut = Indice * PrixPoint
        SalaireNet = SalaireBrut * (1-TauxBrut)

        Console.Write("Le salaire de cet(te) employé(e) est de ")
        Console.Write(SalaireNet)
        Console.Write(" euros net.")

        Console.ReadLine()

    End Sub

End Module
