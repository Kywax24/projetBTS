﻿Module Module1

    Sub Main()
        Dim mot As String = New String("", 4)
        Dim a As Int16
        Dim b As Int16
        Dim c As Int16
        Dim d As Int16


        Console.WriteLine("Changement caractère code ASCII")
        Console.WriteLine("-------------------------------")

        Console.Write("Saisissez un mot de 4 caractères : ")
        mot = Console.ReadLine()

        a = Asc(mot.Chars(0))
        b = Asc(mot.Chars(1))
        c = Asc(mot.Chars(2))
        d = Asc(mot.Chars(3))

        Console.WriteLine()
        Console.WriteLine("Le mot " & mot & " a pour code ASCII : " & a & " " & b & " " & c & " " & d)
        Console.ReadLine()
    End Sub

End Module
