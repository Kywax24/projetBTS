﻿Module Exercice11_tromper_utilisateur

    Sub Main()
        Dim x As Int16
        Dim y As Int16
        Dim z As Int16

        Console.Write("Saisissez x : ")
        x = Console.ReadLine
        Console.Write("Saisissez y : ")
        y = Console.ReadLine
        Console.Write("Saisissez z : ")
        z = Console.ReadLine

        Console.WriteLine()

        Console.Write("Après changement, x vaut " & z & ", y vaut " & x & ", z vaut " & y & ".")

        Console.ReadLine()
    End Sub

End Module
