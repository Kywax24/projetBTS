﻿Module Exercice9

    Sub Main()
        Dim Nom As String
        Dim SalaireNet As Double
        Dim SalaireHoraire As Double
        Dim NombreHeures As Double
        Dim TauxRetenu As Double
        Dim MontantPrime As Double

        Console.WriteLine("Description d'un employé et son salaire")
        Console.Write("Nom : ")
        Nom = Console.ReadLine()
        Console.Write("Salaire horaire : ")
        SalaireHoraire = Console.ReadLine()
        Console.Write("Nombre d'heure travaillée : ")
        NombreHeures = Console.ReadLine()
        Console.Write("Taux de retenue : ")
        TauxRetenu = Console.ReadLine()
        Console.Write("Montant de la prime : ")
        MontantPrime = Console.ReadLine()

        SalaireNet = ((NombreHeures * SalaireHoraire) + MontantPrime) * (1 - TauxRetenu)

        Console.WriteLine()
        Console.Write(Nom)
        Console.Write(" touche ")
        Console.Write(SalaireNet)
        Console.WriteLine(" euros par mois.")

        Console.ReadLine()



    End Sub

End Module
