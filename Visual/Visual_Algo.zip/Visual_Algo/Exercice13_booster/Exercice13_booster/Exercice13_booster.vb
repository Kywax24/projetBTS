﻿Module Exercice13_booster

    Sub Main()
        Dim somme As String
        Dim b100 As Int16
        Dim b50 As Int16
        Dim b10 As Int16
        Dim b5 As Int16
        Dim reponse As String
        Dim sommedepart As String



Boucle: Console.Write("Sasissez la somme d'argent à convertir : ")

        somme = Console.ReadLine()

        If IsNumeric(somme) Then
            sommedepart = somme
            Convert.ToInt16(somme)
        Else
            GoTo Boucle
        End If


        b100 = somme \ 100
        somme = somme Mod 100
        b50 = somme \ 50
        somme = somme Mod 50
        b10 = somme \ 10
        somme = somme Mod 10
        b5 = somme \ 5
        somme = somme Mod 5

        Console.Clear()

        Console.WriteLine("La somme de départ de " & sommedepart & " euros équivaut à : 
        " & b100 & " billet(s) de 100 euros
        " & b50 & " billet(s) de 50 euros
        " & b10 & " billet(s) de 10 euros
        " & b5 & " billet(s) de 5 euros
        " & somme & " pièce(s) de 1 euros")

        Console.WriteLine()

Boucle2: Console.WriteLine("Voulez-vous relancer le programme ? (O/N)")
        reponse = Console.ReadLine()
        If reponse = "O" Or reponse = "o" Then
            Console.Clear()
            GoTo Boucle
        ElseIf reponse = "N" Or reponse = "n" Then
            Console.WriteLine("Fermeture du programme...")
            Threading.Thread.Sleep(1000)
        Else
            GoTo Boucle2
        End If

    End Sub

End Module
