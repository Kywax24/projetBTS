﻿Module Exercice10

    Sub Main()
        Dim TempsSaisi As Int16
        Dim Secondes As Int16
        Dim Minutes As Int16
        Dim Heures As Int16

        Console.WriteLine("Modifier un temps en secondes dans un fuseau horraire H/M/S")

        Console.Write("Saisir un temps en secondes : ")
        TempsSaisi = Console.ReadLine()

        Secondes = TempsSaisi Mod 60
        Minutes = TempsSaisi \ 60
        Heures = Minutes \ 60
        Minutes = Minutes Mod 60

        Console.WriteLine()
        Console.Write(TempsSaisi)
        Console.WriteLine(" secondes dans un fuseau horraire traditionel donne :")
        Console.Write(Heures)
        Console.Write("H ")
        Console.Write(Minutes)
        Console.Write(" M ")
        Console.Write(Secondes)
        Console.Write(" S")

        Console.ReadLine()


    End Sub

End Module
