﻿Module Exercice7

    Sub Main()
        Dim coef1 As Int16
        Dim coef2 As Int16
        Dim coef3 As Int16
        Dim note1 As Int16
        Dim note2 As Int16
        Dim note3 As Int16

        coef1 = 3
        coef2 = 4
        coef3 = 2

        Console.WriteLine("Calculer la moyenne de 3 notes")
        Console.WriteLine("------------------------------")

        Console.WriteLine("Donner la note obtenue à l'épreuve 1 :")
        note1 = Console.ReadLine()
        Console.WriteLine("Donner la note obtenue à l'épreuve 2 :")
        note2 = Console.ReadLine()
        Console.WriteLine("Donner la note obtenue à l'épreuve 3 :")
        note3 = Console.ReadLine()

        Console.WriteLine()

        Console.WriteLine("Epreuve 1 " & note1 & "/20, Coefficiant " & coef1)
        Console.WriteLine("Epreuve 1 " & note2 & "/20, Coefficiant " & coef2)
        Console.WriteLine("Epreuve 1 " & note3 & "/20, Coefficiant " & coef3)

        Console.WriteLine()

        Console.WriteLine("Votre moyenne est de " & (note1 * coef1 + note2 * coef2 + note3 * coef3) / (coef1 + coef2 + coef3) & "/20.")

        Console.ReadLine()

    End Sub

End Module
