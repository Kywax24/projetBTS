﻿Module Exercice8

    Sub Main()
        Dim taux As Double
        Dim prixHT As Double
        Dim tva As Double
        Dim prixTTC As Double

        taux = 0.196

        Console.WriteLine("Calculer la TVA et la prix TTC d'un prix HT")
        Console.WriteLine("-------------------------------------------")

        Console.WriteLine("Saisissez le prix hors taxe :")
        prixHT = Console.ReadLine()

        tva = prixHT * taux
        Console.WriteLine("La TVA est de : " & tva)
        prixTTC = prixHT - tva
        Console.WriteLine("Le prix est de : " & prixTTC)

        Console.ReadLine()

    End Sub

End Module
