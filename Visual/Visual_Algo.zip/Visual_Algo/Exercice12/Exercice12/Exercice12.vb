﻿Module Exercice12

    Sub Main()
        Dim x As Int16

        Console.Write("Saisissez x : ")
        x = Console.ReadLine()


        Console.WriteLine()
        Console.Write("Le nombre " & x & " a pour paire inférieur " & (x \ 2) * 2 & ".")

        Console.ReadLine()
    End Sub

End Module
