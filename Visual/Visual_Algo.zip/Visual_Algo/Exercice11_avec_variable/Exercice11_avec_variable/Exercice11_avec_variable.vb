﻿Module Exercice11_avec_variable

    Sub Main()
        Dim x As Int16
        Dim y As Int16
        Dim z As Int16
        Dim changement As Int16

        Console.Write("Saisissez x : ")
        x = Console.ReadLine
        Console.Write("Saisissez y : ")
        y = Console.ReadLine
        Console.Write("Saisissez z : ")
        z = Console.ReadLine

        changement = y
        y = x
        x = changement
        changement = z
        z = x
        x = changement

        Console.WriteLine()

        Console.Write("Après changement, x vaut ")
        Console.Write(x)
        Console.Write(", y vaut ")
        Console.Write(y)
        Console.Write(", z vaut ")
        Console.Write(z)
        Console.Write(".")


        Console.ReadLine()
    End Sub

End Module
