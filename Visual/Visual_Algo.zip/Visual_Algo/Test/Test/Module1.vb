﻿Module Module1

    Sub Main()
        Dim test As String = Console.ReadLine()

        If IsNumeric(test) Then
            Console.Write("Non")
            Console.ReadLine()
        Else
            Console.Write("Oui")
            Console.ReadLine()
        End If

        Convert.ToInt16(test)
        Console.WriteLine(test)
        test = test + 5
        Console.WriteLine(test)
        Console.ReadLine()
    End Sub

End Module
