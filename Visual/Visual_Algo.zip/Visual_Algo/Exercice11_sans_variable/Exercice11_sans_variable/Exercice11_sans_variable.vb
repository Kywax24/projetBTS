﻿Module Exercice11_sans_variable

    Sub Main()
        Dim x As Int16
        Dim y As Int16
        Dim z As Int16

        Console.Write("Saisissez x : ")
        x = Console.ReadLine
        Console.Write("Saisissez y : ")
        y = Console.ReadLine
        Console.Write("Saisissez z : ")
        z = Console.ReadLine

        x = x + y
        y = x - y
        x = x - y
        z = z + x
        x = z - x
        z = z - x


        Console.WriteLine()

        Console.Write("Après changement, x vaut ")
        Console.Write(x)
        Console.Write(", y vaut ")
        Console.Write(y)
        Console.Write(", z vaut ")
        Console.Write(z)
        Console.Write(".")


        Console.ReadLine()
    End Sub

End Module
