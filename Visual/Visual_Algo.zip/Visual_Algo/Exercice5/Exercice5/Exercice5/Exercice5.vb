﻿Module Exercice5

    Sub Main()
        Dim x As Int16
        Dim y As Int16
        Dim changement As Int16

        Console.WriteLine("Echanger deux nombres")
        Console.Write("Saisissez x : ")
        x = Console.ReadLine()
        Console.Write("Saisissez y : ")
        y = Console.ReadLine()

        changement = x
        x = y
        y = changement

        Console.WriteLine()

        Console.Write("Après changement, x vaut ")
        Console.Write(x)
        Console.Write(" et y vaut ")
        Console.Write(y)


        Console.ReadLine()

    End Sub

End Module
