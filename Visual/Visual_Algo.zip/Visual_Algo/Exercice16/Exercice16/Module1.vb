﻿Module Module1

    Sub Main()
        Dim Nom As String
        Dim Prenom As String
        Dim DateNaissance As String
        Dim NaissJ As Double
        Dim age As Double
        Dim dateSysteme As DateTime = DateTime.Today
        Dim JNow As String = dateSysteme.ToString("dd")
        Dim Mnow As String = dateSysteme.ToString("MM")
        Dim ANow As String = dateSysteme.ToString("yyyy")
        Dim dateNow As Double

        Console.WriteLine("Présentation d'un personne avec nom, prénom et âge")
        Console.WriteLine("--------------------------------------------------")

        Console.WriteLine("Quel est votre nom ?")
        Nom = Console.ReadLine()
        Console.WriteLine("Quel est votre prénom ?")
        Prenom = Console.ReadLine()
        Console.WriteLine("Quelle est votre date de naissance ? (jj/mm/aaaa)")
        DateNaissance = Console.ReadLine()
        NaissJ = Convert.ToDouble(DateNaissance.Substring(0, 2))
        NaissJ = NaissJ + (Convert.ToDouble(DateNaissance.Substring(3, 2)) * (365.25 / 12))
        NaissJ = NaissJ + (Convert.ToDouble(DateNaissance.Substring(6, 4)) * 365.25)
        dateNow = Convert.ToDouble(JNow) + (Convert.ToDouble(Mnow) * (365.25 / 12)) + (Convert.ToDouble(ANow) * 365.25)
        age = dateNow - NaissJ

        'Arrondi à l'entier en dessous
        age = Math.Floor(age / 365.25)



        Console.WriteLine("Vous vous appelez " & Prenom(0) & "." & Nom & " et vous avez " & age & " ans.")
        Console.ReadLine()
    End Sub

End Module
