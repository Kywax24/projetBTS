﻿Module Exercice6

    Sub Main()
        Dim x As Int16
        Dim y As Int16

        Console.WriteLine("Echanger deux nombres")
        Console.Write("Saisissez x : ")
        x = Console.ReadLine
        Console.Write("Saisissez y : ")
        y = Console.ReadLine

        x = x + y
        y = x - y
        x = x - y

        Console.WriteLine()

        Console.Write("Après changement, x vaut ")
        Console.Write(x)
        Console.Write(" et y vaut ")
        Console.Write(y)

        Console.ReadLine()

    End Sub

End Module
