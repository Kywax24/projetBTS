﻿Module Module1

    Sub Main()
        Dim mot As String = New String("", 3)
        Dim a As Int16
        Dim b As Int16
        Dim c As Int16
        Dim charA As String
        Dim charB As String
        Dim charC As String

        Console.WriteLine("Chiffrer un mot de 3 caractères")
        Console.WriteLine("-----------------------------")

        Console.WriteLine("Saisissez un mot de 3 caractères en minuscule")
        mot = Console.ReadLine()
        a = 219 - Asc(mot.Chars(0))
        b = 219 - Asc(mot.Chars(1))
        c = 219 - Asc(mot.Chars(2))

        charA = ChrW(a)
        charB = ChrW(b)
        charC = ChrW(c)




        Console.WriteLine()
        Console.WriteLine("Le code secret est : " & mot(2) & charC & mot(1) & charB & mot(0) & charA)
        Console.ReadLine()
    End Sub

End Module
