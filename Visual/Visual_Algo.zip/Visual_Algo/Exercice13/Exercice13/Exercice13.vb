﻿Module Exercice13

    Sub Main()
        Dim somme As Int16
        Dim b100 As Int16
        Dim b50 As Int16
        Dim b10 As Int16
        Dim b5 As Int16
        Dim reponse As String



Boucle: Console.Write("Sasissez la somme d'argent à convertir : ")

        somme = Console.ReadLine()


        b100 = somme \ 100
        somme = somme Mod 100
        b50 = somme \ 50
        somme = somme Mod 50
        b10 = somme \ 10
        somme = somme Mod 10
        b5 = somme \ 5
        somme = somme Mod 5

        Console.Clear()

        Console.WriteLine("La somme de départ équivaut à : 
        " & b100 & " billet(s) de 100 euros
        " & b50 & " billet(s) de 50 euros
        " & b10 & " billet(s) de 10 euros
        " & b5 & " billet(s) de 5 euros
        " & somme & " pièce(s) de 1 euros")

        Console.ReadLine()

    End Sub

End Module
